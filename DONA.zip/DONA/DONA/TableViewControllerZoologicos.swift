//
//  TableViewControllerZoologicos.swift
//  DONA
//
//  Created by UNAM-Apple12 on 26/10/22.
//

import UIKit

struct Zoologico {
    var nombre: String
    var Usos: String
    var imagen: UIImage
}

class TableViewControllerZoologicos: UITableViewController {

    var Zoologicoseleccionado : Zoologico?
    var listaZoologico: [Zoologico] = [
    Zoologico(nombre: "Zoologico de Chapultepec", Usos:"El Zoológico de Chapultepec, tiene los siguientes 4 objetivos primordiales: recreación, educación, investigación y conservación de especies de fauna silvestre", imagen: UIImage (named: "Chapultepec")!),
    Zoologico(nombre: "Parque ecologico de Zacango", Usos: "Parque Ecológico Zacango está comprometido con la conservación y protección de las especies", imagen: UIImage (named: "Zacango")!),
    Zoologico(nombre: "Zoologico Guadalajara", Usos: "Preservar las especies con las que cuenta el zoologico, insentivar la conservacion y reproduccion de especies amenazdas", imagen: UIImage(named: "GDL")!),
    Zoologico(nombre: "Zoologico San juan de Aragon", Usos: "El Zoologio San Juan de Aragon tiene el compromiso de atender y dar refugio al mayor numero de animales rescatados del trafico ilegal", imagen: UIImage(named: "SJA")!)]

    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaZoologico.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "dona", for: indexPath) as! TableViewCellDona
        
        let Zoologico = listaZoologico[indexPath.row]
        cell.labelZoologicos.text = Zoologico.nombre
        cell.imagenZoologicos.image = Zoologico.imagen
        

        // Configure the cell...

        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
        
    }
        
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) { print(indexPath.row)
            
            Zoologicoseleccionado = listaZoologico[indexPath.row]
         performSegue(withIdentifier: "segueZoologicoMaestroToDetalle", sender: nil)
         
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let siguienteEscena = segue.destination as! ViewControllerZoologicosDetalle
        siguienteEscena.ZoologicoSeleccionado = Zoologicoseleccionado
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

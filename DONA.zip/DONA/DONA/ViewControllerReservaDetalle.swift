//
//  ViewControllerReservaDetalle.swift
//  DONA
//
//  Created by UNAM-Apple12 on 24/11/22.
//

import UIKit

class ViewControllerReservaDetalle: UIViewController {

    var ReservaRecibida : Reserva?
    
    @IBOutlet weak var labelNombre: UILabel!
    
    @IBOutlet weak var imgreserva: UIImageView!
    @IBOutlet weak var labelUsos: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        labelNombre.text = ReservaRecibida?.nombre
        imgreserva.image = ReservaRecibida?.imagen
        labelUsos.text = ReservaRecibida?.usos
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

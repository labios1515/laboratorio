//
//  ViewControllerSantuarioDetalle.swift
//  DONA
//
//  Created by UNAM-Apple12 on 24/11/22.
//

import UIKit

class ViewControllerSantuarioDetalle: UIViewController {
    
    var SantuarioRecibido : Santuario?

    
    @IBOutlet weak var labelNombre: UILabel!
    
    @IBOutlet weak var imgSantuario: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let imagenrecibida = SantuarioRecibido?.imagenGracias, let nombreRecibido = SantuarioRecibido?.nombre{
            imgSantuario.image = imagenrecibida
            labelNombre.text = nombreRecibido
        }
//        labelNombre.text = SantuarioRecibido?.nombre
//        imgSantuario.image = SantuarioRecibido?.imagen

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

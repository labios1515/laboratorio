//
//  TableViewCellDona.swift
//  DONA
//
//  Created by UNAM-Apple12 on 26/10/22.
//

//Comentarios: En la primera escena tenemos una barra que nos da la opcion de buscar zoologicos especificos o en su defecto un animal en especifico// Dentro de las celdas encontramos diferentes formas de donacion como soy con medios electronicos como paypal y tipos de tarjetas como mastercard, asi como tambien donaciones en especie que esta representado por una imagen de carne, tambien se muestra en porcentaje el avance de las donaciones meta en los zoologicos// 

//EN la escena de ajustes se puede iniciar sesion con otros servidores como apple y google que recogen la informacion de servidores externos, asi como tambien se puede ingrear un nuevo perfil en el boton de "crear una cuenta", es importante tener una cuenta ya que se lleva un registro de la cantidad donada y cada 1000 pesos se tiene la opcion de recibir un regalo, ademas de que en la opcion de adoptar animales se te envia a la cuenta proporcionada una constancia y certificado electronico//



import UIKit

class TableViewCellDona: UITableViewCell {


    @IBOutlet weak var labelZoologicos: UILabel!
    
    @IBOutlet weak var imagenZoologicos: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  TableViewCellDestinos.swift
//  canhijo
//
//  Created by UNAM-Apple9 on 25/10/22.
//

import UIKit

class TableViewCellDestinos: UITableViewCell {

    
    @IBOutlet weak var imgDestino: UIImageView!
    

    
    @IBOutlet weak var lblDestino: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  TableViewControllerDestino.swift
//  canhijo
//
//  Created by UNAM-Apple9 on 25/10/22.
//

import UIKit

struct Destinos {
    var nombreLugar : String
    var ubicacion : String
    var nombreEstableecimiento : String
    var estrellas : String
    var imagen : UIImage
    var imagenLugar : UIImage
}

class TableViewControllerDestino: UITableViewController {

    var destinoSeleccionado: Destinos?
    
    var LugarSeleccionado : Destinos?
    
    
    var listaDestinos : [Destinos] = [
        
        Destinos(nombreLugar: "Hoteles", ubicacion: "Puerto Vallarta", nombreEstableecimiento: "Hotel Dreams", estrellas: "5 estrellas", imagen: UIImage(named: "hotel")!, imagenLugar: UIImage(named: "DreamsPV")!),
        Destinos(nombreLugar: "Restaurantes", ubicacion: "CDMX", nombreEstableecimiento: "Juana Juana", estrellas: "5 estrellas", imagen: UIImage(named: "restaurante")!, imagenLugar: UIImage(named: "Juana Juana")!),
        Destinos(nombreLugar: "Tiendas", ubicacion: "Morelos", nombreEstableecimiento: "Petco", estrellas: "5 estrellas", imagen: UIImage(named: "tienda")!, imagenLugar: UIImage(named: "Petco")!),
        Destinos(nombreLugar: "Cafeterias", ubicacion: "CDMX", nombreEstableecimiento: "Garko Cafe", estrellas: "5 estrellas", imagen: UIImage(named: "cafeteria")!, imagenLugar: UIImage(named: "Garko")!),
        Destinos(nombreLugar: "Parques", ubicacion: "CDMX", nombreEstableecimiento: "La Mexicana", estrellas: "5 estrellas", imagen: UIImage(named: "parque")!, imagenLugar: UIImage(named: "La mexicana")!),
        
        

    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaDestinos.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdita", for: indexPath) as! TableViewCellDestinos
        let destino = listaDestinos[indexPath.row]
        
        cell.lblDestino.text = destino.nombreLugar
        cell.imgDestino.image = destino.imagen

        // Configure the cell...

        return cell
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        destinoSeleccionado = listaDestinos [indexPath.row]
        performSegue(withIdentifier: "segueDestinoMaestroToDetalle", sender: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let siguienteVista = segue.destination as! ViewControllerDetalles
        siguienteVista.destinoRecibido  = destinoSeleccionado
    }
//    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        destinoSeleccionado = listaDestinos [indexPath.row]
//        performSegue(withIdentifier: "SegueNoHotel", sender: nil)
//    }

    
    
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

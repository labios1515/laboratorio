//
//  ViewControllerDetalles.swift
//  canhijo
//
//  Created by UNAM-Apple9 on 25/10/22.
//
/*
 
 1. En nuestra primera escena, se encuentra una sección donde se solicitan datos para el inicio de sesión, con correo y contraseña, o en su defecto un inicio con datos recuperados de Apple, Google o Facebook. Además se encuentra un botón que nos guia a 3 opciones del Tab Bar: Misión, Testigos y Configuración.
     El programa que se uso para hacer nuestro logo fue: Zyro Logo Maker (:
 
 2. En nuestra primera opción del Tab Bar se encuentra nuestra misión. En la segunda escena: "Nuestros testigos", se puede observar un espacio con algunos comentarios de nuestros usuarios que han usado la app, y por ultimo, en la tercera se puede encontrar la configuración que nos muestra diferentes opciones, entre ellas el uso sensores como: la red movil y ubicación.
 3. Dando inicio a nuestra app, se encuentra una escena que nos muestra una barra de busqueda, que al darle click nos dirige a una tabla con los nombres de los diferentes sitios que se puden visitar.
 4. Al seleccionar uno de los sitios, se sigue a la escena "Busca tu opción", que tiene la función de la busqueda de la opción que desee el usuario, además de encontrar como detalle una recomendación, que muestra nombre, estrellas y ubicación, ademas de un botón de disponibilidad. Al final de esta escena nos encontramos con un botos de "Ver más opciones", la cual nos guia a la siguiente escena.
 5. En la escena de Filtros, se encuentran diversas opciones para filtrar nuestra busqueda, para finalmente llegar al botón de "Mostrar resultados", que nos guia a nuestra última escena donde se muestran los resultados con base a los filtros seleccionados, al final con un botón de disponibilidad.

 */
 
/* Perfil del cliente
 
 1. Trabajos de cliente
 Encontrar sitios que permitan la entrada con mascotas: en la escena de “A donde ir con tu mascota'' te muestra el listado de tipos de sitios a donde se puede ir y posteriormente la opción para buscar por ubicación.
 Comparar precios, ubicaciones, disponibilidad y lugares pet friendly. Después de haber seleccionado la ubicación de a donde se desea ir, se encuentra en la escena de “Filtros''. En el primer filtro se puede seleccionar el rango de precio y posteriormente ver la disponibilidad del lugar.
 Reservar hospedaje considerando la fecha y hora. En la parte de “Filtros” está la opción para elegir la fecha y el horario deseado.
 
 2. Dolores
 Pérdida de tiempo al tener que buscar sitios pet friendly. Todas las escenas permiten que la aplicación sea intuitiva por lo que es muy sencillo encontrar sitios pet friendly.
 Estrés por no encontrar sitios que acepten la estancia con mascotas.Todas las estancias y sitios de la aplicación son pet friendly, solo es necesario ingresar el lugar deseado y los filtros de preferencia para una mejor experiencia.
 Miedo por no saber si hay disponibilidad. En la escena “Selecciona una fecha” aparece un lugar recomendado y desde ahí es posible ver su disponibilidad, también es posible ver esta opción en la escena de “Resultados” seleccionando la estancia deseada.
 
 3. Ganancias
 Tener variedad de lugares pet friendly. Se logra en la escena de “Sitios”, primero buscando por el tipo de lugar y después más específicamente la ubicación y se desplegaran todas las opciones de sitios que sean pet friendly.
 Generar confianza en la aplicación a través de las referencias. En la escena de “Referencias” se puede apreciar ejemplos de personas que cuentan su experiencia con la aplicación y con los sitios que han visitado que permite saber cuál fue el agrado de otras personas y generar confianza para los que no la han probado.

 
 */

import UIKit

class ViewControllerDetalles: UIViewController {
    var destinoRecibido : Destinos?
  
   
    @IBOutlet weak var TxtUbicacion: UITextField!
    
    let Ubicaciones = ["Cancún", "Puerto Vallarta", "Los Cabos"]
    var pickerView = UIPickerView()
    
    
    @IBOutlet weak var steeper: UIStepper!
    @IBOutlet weak var steeper2: UIStepper!
    
    @IBOutlet weak var lblNumeroSteeper: UILabel!
    @IBOutlet weak var lblNumeroSteeper2: UILabel!
    
    @IBOutlet weak var imgLugar: UIImageView!
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblPrecio: UILabel!
    @IBOutlet weak var lblUbicacion: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        imgLugar.image = destinoRecibido?.imagenLugar
        lblNombre.text = destinoRecibido?.nombreEstableecimiento
        lblPrecio.text = destinoRecibido?.estrellas
        lblUbicacion.text = destinoRecibido?.ubicacion
        
        steeper.minimumValue = 1
        steeper.maximumValue = 15

        pickerView.delegate = self
        pickerView.dataSource = self
        
        TxtUbicacion.inputView = pickerView
        
        steeper2.minimumValue = 1
        steeper2.maximumValue = 5

        pickerView.delegate = self
        pickerView.dataSource = self
        
        TxtUbicacion.inputView = pickerView
        
    }
    
    
    
    @IBAction func actualizarLabelSteeper(_ sender: Any) {
        
        lblNumeroSteeper.text = String(Int(steeper.value))
    }
    
   
    @IBAction func actulizarLabelSteeoer2(_ sender: Any) {
        lblNumeroSteeper2.text = String(Int(steeper2.value))
    }
    
    
      
        
    }
    
    


extension ViewControllerDetalles : UIPickerViewDelegate, UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        Ubicaciones.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return Ubicaciones[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
    
        TxtUbicacion.text = Ubicaciones[row]
        TxtUbicacion.resignFirstResponder()
    }
    
}


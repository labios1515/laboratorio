//
//  ViewControllerDetalleNoHotel.swift
//  canhijo
//
//  Created by UNAM-Apple9 on 25/11/22.
//

import UIKit

class ViewControllerDetalleNoHotel: UIViewController {
    
    @IBOutlet weak var LabelNombre: UILabel!
    @IBOutlet weak var LabelEstrellas: UILabel!
    @IBOutlet weak var LabelUbicacion: UILabel!
    @IBOutlet weak var LabelRangoPrecio: UILabel!
    @IBOutlet weak var ImagenNoHotel: UIImageView!
    
    var LugarRecibido : Destinos?
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
